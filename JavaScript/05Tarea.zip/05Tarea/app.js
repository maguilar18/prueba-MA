var http = require('http');
var url = require("url");
var soap = require('soap');
var xml2js = require('xml2js');
var fs = require('fs');

var parser = xml2js.parseString;
var url2 = "http://www.webservicex.com/globalweather.asmx?wsdl";

var lista;




function peticionSOAP(result){
    return new Promise((resolve, reject) => {
            var pais = result.pais;
            var res = result.res;
        soap.createClient(url2, function(err, client) {
            var args = {CountryName: pais};
            client.GetCitiesByCountry(args, function(err, result) {
                parser(result.GetCitiesByCountryResult, (err, result)=>{
                       resolve({lista:result.NewDataSet.Table, res:res});
                });
            });
        });
    });
}

function guardarArchivo(result){
    return new Promise((resolve, reject) => {
        var lista = result.lista;
        var res = result.res;
        var listaStr = "";
        lista.forEach(ciudad => {
            listaStr += ciudad.City + "\n";
        });


        res.end(listaStr);
        fs.writeFile(lista[0].Country +".txt", listaStr, (err) => {

        });
    })
}


var server = http.createServer(function (req, res) {
    res.writeHead(200, {'Content-Type': 'text/plain'});
    var parsedUrl = url.parse(req.url, true); // true to get query as object
    var queryAsObject = parsedUrl.query;
    pais = queryAsObject.pais;
    console.log(pais);
    if(pais)
        peticionSOAP({pais: pais, res:res})
            .then(result => guardarArchivo(result));
}).listen(3000, '127.0.0.1');


console.log('Server running at http://127.0.0.1:3000')